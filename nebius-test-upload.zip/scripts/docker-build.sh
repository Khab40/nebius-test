#!/usr/bin/env bash
set -euo pipefail
docker build -t nebius-test:local .
